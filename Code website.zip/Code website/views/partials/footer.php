<html>
<bodyy>

    <div class="footer">
        <p class="footertext">Gezinshuis</p>
    </div>

</bodyy>


</html>