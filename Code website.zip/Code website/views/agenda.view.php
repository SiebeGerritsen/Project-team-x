<?php
$page = 'agenda'
?>

    <!DOCTYPE html>

    <html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>PHP Event Calendar by CodexWorld</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="bootstrap.min.css">

</head>




<body>

    <div class="container-fluid" style="margin-top:0px">
        <div class="row">

            <div class="col-sm-4">

                <?php
                include_once 'public/personalMenu.php';
                ?>

                <hr class="d-sm-none">
            </div>

            <div class="col-sm-8">

                <h2>Agenda</h2>

                <div class="container">

                        <?php
                        include_once 'core/calendar.php';
                        ?>

                </div>



            </div>
        </div>
    </div>

    <?php
    include_once 'partials/footer.php';
    ?>

    </body>


    </html>
<?php
/**
 * Created by PhpStorm.
 * User: Siebe
 * Date: 11-10-2018
 * Time: 21:13
 */