<?php
/**
 * Created by: Siebe
 * Team-x
 */


require 'views/personalPage.view.php';
