<?php
/*
 *  @internal view index.php
 */



require 'views/index.view.php';

/**
 * Created by PhpStorm.
 * User: Siebe
 * Date: 11-10-2018
 * Time: 14:33
 */