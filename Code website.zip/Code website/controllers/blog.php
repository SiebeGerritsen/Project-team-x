<?php

$msg ='';
$result = false;

if(isset($_POST['submit'])){
    rewuire_once
}

require 'views/blog.view.php';
/**
* Created by PhpStorm.
* User: Siebe
* Date: 10-10-2018
* Time: 00:15
*/