<?php

class BlogPost
{
    public $id;
    public $datum;
    public $description;
    public $result;
    public $blogPost = [];


    /**
     * @return mixed
     */

}




/**
 * Created by PhpStorm.
 * User: Siebe
 * Date: 12-10-2018
 * Time: 12:00
 */