<?php

return[
    'database'=> [
        'name' => 'gasthuis',
        'username' => 'root',
        'password' => 'hallo531',
        'connection' => 'mysql:host=127.0.0.1',
        'options' => [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING
        ]
    ]

];
/**
 * Created by PhpStorm.
 * User: Siebe
 * Date: 11-10-2018
 * Time: 20:34
 */